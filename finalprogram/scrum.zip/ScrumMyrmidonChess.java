public class ScrumMyrmidonChess{
	public static void main(String[] args) {
		Board.getInstance().newGame();
	}
}